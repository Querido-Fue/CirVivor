/** 충돌 body kind의 SoA 코드 값입니다. */
const COLLISION_BODY_KIND_CODES = Object.freeze({
    NONE: 0,
    ENEMY: 1,
    PLAYER: 2,
    WALL: 3,
    PROJECTILE: 4,
    ITEM: 5
});

/** 충돌 body kind 문자열을 SoA 코드로 변환하는 정적 매핑입니다. */
const COLLISION_BODY_KIND_CODE_BY_NAME = Object.freeze({
    enemy: COLLISION_BODY_KIND_CODES.ENEMY,
    player: COLLISION_BODY_KIND_CODES.PLAYER,
    wall: COLLISION_BODY_KIND_CODES.WALL,
    projectile: COLLISION_BODY_KIND_CODES.PROJECTILE,
    item: COLLISION_BODY_KIND_CODES.ITEM
});

/** 충돌 body shape의 SoA 코드 값입니다. */
const COLLISION_BODY_SHAPE_CODES = Object.freeze({
    NONE: 0,
    CIRCLE: 1,
    CIRCLE_PARTS: 2,
    RECT: 3
});

/** 충돌 body shape 문자열을 SoA 코드로 변환하는 정적 매핑입니다. */
const COLLISION_BODY_SHAPE_CODE_BY_NAME = Object.freeze({
    circle: COLLISION_BODY_SHAPE_CODES.CIRCLE,
    circleParts: COLLISION_BODY_SHAPE_CODES.CIRCLE_PARTS,
    rect: COLLISION_BODY_SHAPE_CODES.RECT
});

/**
 * 충돌 시스템의 정적 튜닝 상수입니다.
 */
export const COLLISION_CONSTANTS = Object.freeze({
    EPSILON: 1e-6,
    RULES: Object.freeze({
        NONE: Object.freeze({
            check: false,
            resolve: false,
            movableA: null,
            movableB: null,
            oneShotByProjectile: false,
            applyImpactRotation: false
        }),
        DYNAMIC_RESOLVE: Object.freeze({
            check: true,
            resolve: true,
            movableA: null,
            movableB: null,
            oneShotByProjectile: false,
            applyImpactRotation: false
        }),
        ENEMY_PLAYER: Object.freeze({
            check: true,
            resolve: true,
            movableA: true,
            movableB: false,
            oneShotByProjectile: false,
            applyImpactRotation: false
        }),
        PLAYER_ENEMY: Object.freeze({
            check: true,
            resolve: true,
            movableA: false,
            movableB: true,
            oneShotByProjectile: false,
            applyImpactRotation: false
        }),
        PROJECTILE_ENEMY: Object.freeze({
            check: true,
            resolve: false,
            movableA: null,
            movableB: null,
            oneShotByProjectile: true,
            applyImpactRotation: true
        }),
        PLAYER_PROJECTILE: Object.freeze({
            check: true,
            resolve: false,
            movableA: null,
            movableB: null,
            oneShotByProjectile: true,
            applyImpactRotation: false
        }),
        PLAYER_ITEM: Object.freeze({
            check: true,
            resolve: false,
            movableA: null,
            movableB: null,
            oneShotByProjectile: false,
            applyImpactRotation: false
        }),
        PROJECTILE_PROJECTILE: Object.freeze({
            check: true,
            resolve: false,
            movableA: null,
            movableB: null,
            oneShotByProjectile: true,
            applyImpactRotation: false
        }),
        WALL_PROJECTILE: Object.freeze({
            check: true,
            resolve: false,
            movableA: false,
            movableB: true,
            oneShotByProjectile: false,
            applyImpactRotation: false
        }),
        PROJECTILE_WALL: Object.freeze({
            check: true,
            resolve: false,
            movableA: true,
            movableB: false,
            oneShotByProjectile: false,
            applyImpactRotation: false
        }),
        WALL_OTHER: Object.freeze({
            check: true,
            resolve: true,
            movableA: false,
            movableB: true,
            oneShotByProjectile: false,
            applyImpactRotation: false
        }),
        OTHER_WALL: Object.freeze({
            check: true,
            resolve: true,
            movableA: true,
            movableB: false,
            oneShotByProjectile: false,
            applyImpactRotation: false
        })
    }),
    FRAME_STATS: Object.freeze({
        BASE_FIELDS: Object.freeze([
            'collisionCheckCount',
            'aabbPassCount',
            'aabbRejectCount',
            'circlePassCount',
            'circleRejectCount',
            'partChecks'
        ]),
        PROFILE_FIELDS: Object.freeze([
            'enemyTotalMs',
            'enemyBodyBuildMs',
            'playerBodyBuildMs',
            'wallBodyBuildMs',
            'enemyPositionSolveMs',
            'enemyStabilizeMs',
            'enemyNonPositionMs',
            'solveGridMs',
            'solvePairScanMs',
            'solveCandidateBuildMs',
            'solvePairProcessMs',
            'solveNarrowphaseMs',
            'projectileTotalMs',
            'projectileEnemyBodyBuildMs',
            'projectileGridBuildMs',
            'projectileScanMs',
            'projectileCandidateQueryMs',
            'projectileNarrowphaseMs',
            'contactTotalMs',
            'contactBodyBuildMs',
            'contactGridBuildMs',
            'contactPairScanMs',
            'solveBucketPairCount',
            'solveCandidatePairCount',
            'solveDuplicatePairSkipCount',
            'solveRuleRejectCount',
            'solveAabbPassCount',
            'solveCirclePassCount',
            'solveResolvedPairCount',
            'solveSoACirclePairCount',
            'solveObjectNarrowphasePairCount',
            'solveBudgetSkipCount',
            'solveLargePopulationMode',
            'solvePassCount',
            'solveGridRebuildCount',
            'solveDensePressure',
            'solveGuaranteedPairCount',
            'solvePriorityAdmissionCount',
            'solvePredictiveAdmissionCount',
            'solveAdmissionBudgetSkipCount',
            'solveCandidateVisitCount',
            'solveScanTruncateCount'
        ])
    }),
    GRID: Object.freeze({
        CELL_KEY_OFFSET: 4096,
        CELL_KEY_STRIDE: 8192,
        MIN_CELL_SIZE: 20,
        MAX_CELL_SIZE: 280,
        CELL_SIZE_RADIUS_SCALE: 2.4,
        DEFAULT_RADIUS_WORLD_RATIO: 0.015,
        DEFAULT_RADIUS_MIN: 12,
        RADIUS_SCALE: 1.03,
        QUERY_INITIAL_CAPACITY: 1024,
        BROADPHASE_INITIAL_CAPACITY: 1024,
        BUCKET_INITIAL_CAPACITY: 8
    }),
    SOLVER: Object.freeze({
        DEFAULT_PHYSICS_ITERATION_COUNT: 3,
        PROJECTILE_SWEEP_RADIUS_STEP: 0.45
    }),
    SLEEP: Object.freeze({
        IDLE_TICKS_TO_SLEEP: 45,
        TICKS: 2,
        SPEED_SQ: 9
    }),
    ENEMY_PAIR_PROCESS_BUDGET: Object.freeze({
        POSITION: 14,
        STABILIZE: 10,
        NON_POSITION: 8,
        ANCHOR_MULTIPLIER: 2
    }),
    ENEMY_PAIR_CANDIDATE_BUDGET: Object.freeze({
        CURRENT_OVERLAP_PER_QUERY: 12,
        PREDICTIVE_PER_QUERY: 2,
        UNIQUE_VISITS_PER_QUERY: 32,
        ANCHOR_MULTIPLIER: 2
    }),
    RESOLVE_TUNING: Object.freeze({
        FRAME_MAX_RATIO: 0.42,
        FRAME_MIN_MAX: 2.2,
        MIN_MAX: 1.25,
        HEXA_HIVE_RADIUS_SCALE: 1.1,
        HEXA_HIVE_RADIUS_ROOT_SCALE: 0.55,
        ENEMY_PAIR_RADIUS_BASE_SCALE: 0.9,
        ENEMY_PROJECTILE_RADIUS_BASE_SCALE: 1.1,
        HEXA_HIVE_CELL_RADIUS_BASE: 0.47,
        DEFAULT_BODY_RADIUS: 16,
        PERCENT: 0.55,
        SLOP: 0.8,
        MAX_RATIO: 0.16,
        RADIUS_TUNING_SCALE: 0.85,
        DENSE_POSITION_SOLVE_MAX_PASSES: 3,
        DENSE_PRESSURE_LOCAL_START: 4,
        DENSE_PRESSURE_LOCAL_FULL: 14,
        DENSE_PRESSURE_GLOBAL_FULL: 0.45,
        DENSE_POPULATION_BLEND_START: 256,
        DENSE_POPULATION_BLEND_END: 800,
        DENSE_ITERATION_RESOLVE_BOOST_MIN: 1.18,
        DENSE_ITERATION_RESOLVE_BOOST_MAX: 1.28,
        DENSE_RESOLVE_BOOST_MIN: 1.55,
        DENSE_RESOLVE_BOOST_MAX: 1.85,
        DENSE_CORRECTION_CANDIDATE_THRESHOLD: 5,
        DENSE_CORRECTION_SCALE_PER_NEIGHBOR: 0.06,
        DENSE_CORRECTION_SCALE_MAX: 2.4,
        DENSE_FRAME_CANDIDATE_THRESHOLD: 6,
        DENSE_FRAME_SCALE_PER_NEIGHBOR: 0.065,
        DENSE_FRAME_SCALE_MAX: 2.5,
        PRESSURE_WEIGHT_MIN: 0.35,
        PRESSURE_WEIGHT_MAX: 8,
        PRESSURE_HEXA_HIVE_WEIGHT_MAX: 64,
        PRESSURE_WEIGHT_EXPONENT: 0.6,
        MERGE_PENDING_RESOLVE_WEIGHT: 100000,
        PRESSURE_ENTRY_THRESHOLD: 4,
        PRESSURE_ENTRY_SCALE_PER_NEIGHBOR: 0.14,
        PRESSURE_ENTRY_SCALE_MAX: 2.8,
        PRESSURE_ESCAPE_THRESHOLD: 8,
        PRESSURE_ESCAPE_SCALE_PER_NEIGHBOR: 0.055,
        PRESSURE_ESCAPE_SCALE_MAX: 1.45,
        HEXA_HIVE_WALL_MIN_PARTS: 2
    }),
    BODY_TRANSLATION: Object.freeze({
        AXIS_RESISTANCE_MIN: 0.25,
        AXIS_RESISTANCE_GAIN: 0.85,
        AXIS_RESISTANCE_RADIUS_RATIO: 0.35,
        AXIS_RESISTANCE_RADIUS_MIN: 1
    }),
    MANIFOLD: Object.freeze({
        MULTI_CONTACT_NORMAL_DIVERSITY_SCALE: 0.9,
        MULTI_CONTACT_PENETRATION_MULTIPLIER_MAX: 1.85,
        MULTI_CONTACT_DIVERSITY_SAMPLE_CAP: 3
    }),
    PROJECTILE_IMPACT: Object.freeze({
        ROTATION_IMPULSE_SCALE: 0.12,
        ROTATION_RESPONSE_MULTIPLIER: 1.3,
        PROJECTILE_WEIGHT_MIN: 0.01,
        ENEMY_WEIGHT_MIN: 0.1
    }),
    CANDIDATE_PAIR_BUFFER: Object.freeze({
        INITIAL_PAIR_CAPACITY: 32768,
        INITIAL_BODY_CAPACITY: 1024
    }),
    BODY_BUILDER: Object.freeze({
        CIRCLE_PART_STRIDE: 3,
        BOUND_RADIUS_HALF_SCALE: 0.5,
        DEGREES_TO_RADIANS: Math.PI / 180
    }),
    SOA_LAYOUT: Object.freeze({
        BROAD_STRIDE: 14,
        RELATION_BROAD_STRIDE: 8,
        CONTACT_RESULT_STRIDE: 8,
        BODY_KIND: COLLISION_BODY_KIND_CODES,
        BODY_KIND_CODE_BY_NAME: COLLISION_BODY_KIND_CODE_BY_NAME,
        BODY_SHAPE: COLLISION_BODY_SHAPE_CODES,
        BODY_SHAPE_CODE_BY_NAME: COLLISION_BODY_SHAPE_CODE_BY_NAME,
        RELATION_INDEX: Object.freeze({
            MIN_X: 0,
            MAX_X: 1,
            MIN_Y: 2,
            MAX_Y: 3,
            CENTER_X: 4,
            CENTER_Y: 5,
            ENEMY_PAIR_RADIUS: 6,
            PROJECTILE_RADIUS: 7
        }),
        CONTACT_RESULT_INDEX: Object.freeze({
            PAIR_INDEX: 0,
            BODY_A_INDEX: 1,
            BODY_B_INDEX: 2,
            NORMAL_X: 3,
            NORMAL_Y: 4,
            PENETRATION: 5,
            POINT_X: 6,
            POINT_Y: 7
        })
    })
});
