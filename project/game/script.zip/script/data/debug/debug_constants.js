/**
 * 디버그 표시와 계측에 사용하는 정적 상수입니다.
 */
export const DEBUG_CONSTANTS = Object.freeze({
    DEBUG_OVERLAY: Object.freeze({
        LAYER: 90,
        DIM_ALPHA: 0.16,
        WIDTH_UIWW_RATIO: 0.36,
        HEIGHT_WH_RATIO: 0.52,
        PADDING_X_WW: 1.8,
        TOP_SPACE_WH: 2.2,
        TITLE_DIVIDER_TOP_SPACE_WH: 1,
        TITLE_DIVIDER_BOTTOM_SPACE_WH: 1.8,
        ROW_CONTROL_GAP_WW: 1.5,
        ROW_GAP_WH: 1.35,
        TOGGLE_WIDTH_WW: 4.8,
        TOGGLE_HEIGHT_WH: 2.4,
        HINT_TOP_SPACE_WH: 0.3,
        FOOTER_BOTTOM_SPACE_WH: 2.2,
        FOOTER_BUTTON_GAP_WW: 1
    }),
    RELEASE_SIMULATION_PROFILER: Object.freeze({
        RATE_WINDOW_MS: 1000,
        QUANTILE_WINDOW_MS: 10000,
        SNAPSHOT_INTERVAL_MS: 1000,
        FRAME_RING_CAPACITY: 4096,
        FIXED_RING_CAPACITY: 1024,
        QUANTILE_P50: 0.5,
        QUANTILE_P95: 0.95,
        QUANTILE_P99: 0.99,
        HUD: Object.freeze({
            FONT_MIN_SIZE: 11,
            FONT_WW_RATIO: 0.0075,
            LINE_HEIGHT_RATIO: 1.32,
            X_WW_RATIO: 0.985,
            Y_WH_RATIO: 0.04,
            PANEL_PADDING_RATIO: 0.65,
            PANEL_CHAR_WIDTH_RATIO: 0.56,
            PANEL_FILL: 'rgba(0, 0, 0, 0.72)',
            TEXT_FILL: '#FFFFFF',
            FONT_WEIGHT: 500
        })
    }),
    PERFORMANCE: Object.freeze({
        WINDOW_MS: 1000,
        MAX_VISIBLE_SECTIONS: 42,
        MIN_VISIBLE_AVERAGE_MS: 0.01,
        FONT_MIN_SIZE: 12,
        FONT_WH_RATIO: 0.014,
        LINE_GAP_MIN: 4,
        LINE_GAP_WH_RATIO: 0.004,
        PANEL_PADDING_MIN: 6,
        PANEL_PADDING_WH_RATIO: 0.005,
        START_OFFSET_MIN: 10,
        START_OFFSET_WH_RATIO: 0.01,
        CHAR_WIDTH_RATIO: 0.58,
        SECTION_LABEL_MAX_LENGTH: 30,
        TRUNCATE_MARK_LENGTH: 3,
        TRUNCATE_EDGE_MIN_LENGTH: 4,
        PANEL_FILL: 'rgba(0, 0, 0, 0.78)',
        TEXT_FILL: '#FFFFFF',
        FONT_WEIGHT: 600
    })
});
