import { CollisionHandler } from './_collision_handler.js';

let physicsSystemInstance = null;

/**
 * @class PhysicsSystem
 * @description 고정 틱 물리 연산(충돌 판정/해소)을 담당합니다.
 */
export class PhysicsSystem {
    /**
     * 충돌 핸들러를 생성하고 physics system singleton을 등록합니다.
     */
    constructor() {
        physicsSystemInstance = this;
        this.collisionHandler = new CollisionHandler();
    }

    /**
     * 벽 충돌 체 목록을 설정합니다.
     * @param {object[]} walls
     */
    setWalls(walls = []) {
        this.collisionHandler.setWalls(walls);
    }

    /**
     * 등록된 벽 충돌체 목록을 반환합니다.
     * @returns {object[]}
     */
    getWalls() {
        return this.collisionHandler.getWalls();
    }

    /**
     * 고정 틱 충돌 통계 카운터를 초기화합니다.
     */
    beginFrame() {
        this.collisionHandler.resetFrameStats();
    }

    /**
     * 마지막 고정 틱 충돌 체크 통계를 반환합니다.
     * @returns {object}
     */
    getCollisionStats() {
        return this.collisionHandler.getFrameStats();
    }

    /**
     * contact와 본 solve가 공유할 enemy collision frame을 준비합니다.
     * @param {object[]} enemies - 현재 fixed tick의 전체 적 목록입니다.
     * @param {{delta?:number}} [options] - fixed step 옵션입니다.
     * @returns {number} 준비한 활성 enemy body 수입니다.
     */
    prepareEnemyCollisionFrame(enemies, options = {}) {
        return this.collisionHandler.prepareEnemyCollisionFrame(enemies, options);
    }

    /**
     * 적 충돌을 해소합니다.
     * @param {object[]} enemies
     * @param {object} [options]
     * @returns {number}
     */
    resolveEnemyCollisions(enemies, options = {}) {
        return this.collisionHandler.resolveEnemyCollisions(enemies, options);
    }

    /**
     * 투사체 vs 적 충돌을 처리합니다.
     * @param {object[]} projectiles
     * @param {object[]} enemies
     * @param {number} delta
     * @returns {number}
     */
    resolveProjectileVsEnemies(projectiles, enemies, delta) {
        return this.collisionHandler.resolveProjectileVsEnemies(projectiles, enemies, delta);
    }

    /**
     * 적 목록 중 실제 접촉 중인 적 쌍을 exact 판정으로 수집합니다.
     * @param {object[]} enemies
     * @param {{delta?: number}} [options]
     * @returns {{enemyA: object, enemyB: object}[]} 다음 contact 조회 전까지 유효한 재사용 결과 배열입니다.
     */
    collectEnemyContactPairs(enemies, options = {}) {
        return this.collisionHandler.collectEnemyContactPairs(enemies, options);
    }
}

/**
 * 현재 생성된 physics system singleton을 반환합니다.
 * @returns {PhysicsSystem|null} physics system 인스턴스입니다.
 */
export const getPhysicsSystem = () => physicsSystemInstance;
