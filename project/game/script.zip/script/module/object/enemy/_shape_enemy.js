import { getObjectOffsetY, renderGL } from 'display/display_system.js';
import { BaseEnemy } from './_base_enemy.js';
import { getData } from 'data/data_handler.js';
import { colorUtil } from 'util/color_util.js';
import { clamp01 } from 'util/number_util.js';
import { drawEnemyCollisionDebugCircles } from './_enemy_collision_debug.js';

const ENEMY_ASPECT_RATIO = getData('ENEMY_ASPECT_RATIO');
const ENEMY_HEIGHT_SCALE = getData('ENEMY_HEIGHT_SCALE');
const getEnemyShapeKey = getData('getEnemyShapeKey');
const ENEMY_CONSTANTS = getData('ENEMY_CONSTANTS');
const ENEMY_ANGLE_CONSTANTS = ENEMY_CONSTANTS.ANGLE;
const ENEMY_HEADING_CONSTANTS = ENEMY_CONSTANTS.SHAPE_HEADING;
const HEADING_TRACK_TYPES = new Set(ENEMY_HEADING_CONSTANTS.TRACK_TYPES);
const HEADING_TURN_MAX_DEG_PER_SEC = ENEMY_HEADING_CONSTANTS.TURN_MAX_DEG_PER_SEC;
const HEADING_TURN_DAMP_START_DEG = ENEMY_HEADING_CONSTANTS.TURN_DAMP_START_DEG;
const HEADING_TURN_SNAP_EPSILON_DEG = ENEMY_HEADING_CONSTANTS.TURN_SNAP_EPSILON_DEG;
const HEADING_FORWARD_OFFSET_DEG = ENEMY_HEADING_CONSTANTS.FORWARD_OFFSET_DEG;
const HEADING_MIN_SPEED_SQ = ENEMY_HEADING_CONSTANTS.MIN_SPEED_SQ;
const HEADING_SYMMETRY_STEP_BY_TYPE = ENEMY_HEADING_CONSTANTS.SYMMETRY_STEP_BY_TYPE;
const FULL_TURN_DEG = ENEMY_ANGLE_CONSTANTS.FULL_TURN_DEG;
const STRAIGHT_DEG = ENEMY_ANGLE_CONSTANTS.STRAIGHT_DEG;
const DEGREES_TO_RADIANS = ENEMY_ANGLE_CONSTANTS.DEGREES_TO_RADIANS;
const RADIANS_TO_DEGREES = ENEMY_ANGLE_CONSTANTS.RADIANS_TO_DEGREES;
const TITLE_AI_ID = getData('TITLE_CONSTANTS').TITLE_AI.ID;
const EMPTY_DRAW_OPTIONS = Object.freeze({});

/**
 * 타이틀 씬 적인지 판별합니다.
 * @param {object} enemy
 * @returns {boolean}
 */
function isTitleSceneEnemy(enemy) {
    return typeof enemy?.ai?.id === 'string' && enemy.ai.id === TITLE_AI_ID;
}

/**
 * 비타이틀 적 색상을 완전 불투명 문자열로 정규화합니다.
 * @param {string} fill
 * @returns {string}
 */
function normalizeOpaqueEnemyFill(fill) {
    if (typeof fill !== 'string' || fill.length === 0) {
        return ENEMY_CONSTANTS.DEFAULT_STYLE.FILL;
    }

    const parsed = colorUtil().cssToRgb(fill);
    return colorUtil().rgbToString(parsed.r, parsed.g, parsed.b, 1);
}
/**
 * @class ShapeEnemy
 * @description WebGL 도형 아틀라스를 사용하는 적 공통 구현입니다.
 */
export class ShapeEnemy extends BaseEnemy {
    #rotationCacheDeg;
    #rotationCos;
    #rotationSin;
    #renderOptions;
    #collisionDebugOptions;

    /**
     * @param {string} shapeType
     */
    constructor(shapeType) {
        super();
        this.shapeType = shapeType;
        this.aspectRatio = ENEMY_ASPECT_RATIO[shapeType] ?? 1;
        this.heightScale = ENEMY_HEIGHT_SCALE[shapeType] ?? 1;
        this.shapeKey = getEnemyShapeKey(shapeType);
        this.fill = ENEMY_CONSTANTS.DEFAULT_STYLE.FILL;
        this.alpha = ENEMY_CONSTANTS.DEFAULT_STYLE.ALPHA;
        this.rotation = ENEMY_CONSTANTS.DEFAULT_STYLE.ROTATION;
        this.snapRenderTransform();
        this.#rotationCacheDeg = Number.NaN;
        this.#rotationCos = 1;
        this.#rotationSin = 0;
        this.#renderOptions = {
            shape: this.shapeKey,
            x: 0,
            y: 0,
            w: 0,
            h: 0,
            fill: this.fill,
            alpha: this.alpha,
            rotation: this.rotation,
            rotationCos: this.#rotationCos,
            rotationSin: this.#rotationSin
        };
        this.#collisionDebugOptions = {
            enemyType: this.type,
            width: 0,
            height: 0,
            rotationRadians: 0,
            renderX: 0,
            renderY: 0
        };
        this.#syncRotationCache(true);
    }

    /**
         * 풀에서 가져올 때 초기화합니다. 색상/투명도 등을 갱신합니다.
         * @param {object} [data={}] 
         * @returns {ShapeEnemy}
         */
    init(data = {}) {
        super.init(data);
        this.type = data.type ?? this.shapeType;
        this.shapeKey = getEnemyShapeKey(this.type);
        this.fill = isTitleSceneEnemy(this)
            ? (data.fill ?? this.fill ?? ENEMY_CONSTANTS.DEFAULT_STYLE.FILL)
            : normalizeOpaqueEnemyFill(data.fill ?? this.fill ?? ENEMY_CONSTANTS.DEFAULT_STYLE.FILL);
        this.alpha = isTitleSceneEnemy(this)
            ? (data.alpha ?? ENEMY_CONSTANTS.DEFAULT_STYLE.ALPHA)
            : 1;
        this.rotation = data.rotation ?? ENEMY_CONSTANTS.DEFAULT_STYLE.ROTATION;
        this.snapRenderTransform();
        this.#renderOptions.shape = this.shapeKey;
        this.#renderOptions.fill = this.fill;
        this.#renderOptions.alpha = this.alpha;
        this.#syncRotationCache(true);
        return this;
    }

    /**
         * 풀에 반환되거나 재생성 시 초기 상태 템플릿으로 엎어씁니다.
         */
    reset() {
        super.reset();
        const shapeType = this.shapeType ?? this.type ?? 'square';
        this.shapeKey = getEnemyShapeKey(shapeType);
        this.fill = ENEMY_CONSTANTS.DEFAULT_STYLE.FILL;
        this.alpha = ENEMY_CONSTANTS.DEFAULT_STYLE.ALPHA;
        this.rotation = ENEMY_CONSTANTS.DEFAULT_STYLE.ROTATION;
        this.snapRenderTransform();
        if (!(#renderOptions in this) || !this.#renderOptions) return;
        this.#renderOptions.shape = this.shapeKey;
        this.#renderOptions.fill = this.fill;
        this.#renderOptions.alpha = this.alpha;
        this.#syncRotationCache(true);
    }

    /**
         * 회전값이 바뀐 경우에만 삼각함수 캐시를 갱신합니다.
         * @param {boolean} [force=false] 강제 갱신 여부
         * @private
         */
    #syncRotationCache(force = false) {
        if (!this.#renderOptions) return;

        const rotation = Number.isFinite(this.renderRotation) ? this.renderRotation : 0;
        if (!force && this.#rotationCacheDeg === rotation) return;

        this.#rotationCacheDeg = rotation;
        this.#renderOptions.rotation = rotation;

        if (rotation === 0) {
            this.#rotationCos = 1;
            this.#rotationSin = 0;
        } else {
            const rad = rotation * DEGREES_TO_RADIANS;
            this.#rotationCos = Math.cos(rad);
            this.#rotationSin = Math.sin(rad);
        }

        this.#renderOptions.rotationCos = this.#rotationCos;
        this.#renderOptions.rotationSin = this.#rotationSin;
    }

    /**
     * @private
     * @param {number} angle
     * @returns {number}
     */
    #normalizeAngle(angle) {
        if (!Number.isFinite(angle)) return 0;
        let out = angle % FULL_TURN_DEG;
        if (out > STRAIGHT_DEG) out -= FULL_TURN_DEG;
        if (out < -STRAIGHT_DEG) out += FULL_TURN_DEG;
        return out;
    }

    /**
     * @private
     * @param {number} fromDeg
     * @param {number} toDeg
     * @returns {number}
     */
    #shortestAngleDelta(fromDeg, toDeg) {
        return this.#normalizeAngle(toDeg - fromDeg);
    }

    /**
     * 도형 대칭성을 고려해 가장 짧은 회전 델타를 구합니다.
     * triangle: 120도 대칭, rhom: 180도 대칭
     * @private
     * @param {number} currentDeg
     * @param {number} targetDeg
     * @returns {number}
     */
    #headingDeltaWithSymmetry(currentDeg, targetDeg) {
        const type = this.type ?? this.shapeType;
        const symmetryStep = HEADING_SYMMETRY_STEP_BY_TYPE[type] ?? FULL_TURN_DEG;

        if (symmetryStep >= FULL_TURN_DEG) {
            return this.#shortestAngleDelta(currentDeg, targetDeg);
        }

        const turns = Math.floor(FULL_TURN_DEG / symmetryStep);
        let bestDelta = this.#shortestAngleDelta(currentDeg, targetDeg);
        for (let i = 1; i < turns; i++) {
            const candidate = targetDeg + (symmetryStep * i);
            const candidateDelta = this.#shortestAngleDelta(currentDeg, candidate);
            if (Math.abs(candidateDelta) < Math.abs(bestDelta)) {
                bestDelta = candidateDelta;
            }
        }
        return bestDelta;
    }

    /**
     * 삼각형/화살표/마름모 계열의 머리를 이동 방향으로 서서히 회전시킵니다.
     * @private
     * @param {number} delta
     */
    #updateHeadingRotation(delta) {
        const type = this.type ?? this.shapeType;
        if (!HEADING_TRACK_TYPES.has(type)) return;

        const velX = this.speed.x * this.moveSpeed;
        const velY = this.speed.y * this.moveSpeed;
        const speedSq = (velX * velX) + (velY * velY);
        if (speedSq < HEADING_MIN_SPEED_SQ) return;

        const targetDeg = (Math.atan2(velY, velX) * RADIANS_TO_DEGREES) + HEADING_FORWARD_OFFSET_DEG;
        const currentDeg = Number.isFinite(this.rotation) ? this.rotation : 0;
        const deltaDeg = this.#headingDeltaWithSymmetry(currentDeg, targetDeg);
        const absDelta = Math.abs(deltaDeg);
        if (absDelta <= HEADING_TURN_SNAP_EPSILON_DEG) {
            this.rotation = currentDeg + deltaDeg;
            return;
        }

        // 목표 각도에 가까워질수록 회전 속도를 감쇠합니다.
        const dampRatio = clamp01(absDelta / HEADING_TURN_DAMP_START_DEG);
        const speedScale = dampRatio * dampRatio * (3 - (2 * dampRatio)); // smoothstep(0~1)
        const turnSpeed = HEADING_TURN_MAX_DEG_PER_SEC * speedScale;
        const maxStep = turnSpeed * delta;
        const step = Math.min(absDelta, maxStep);
        this.rotation = currentDeg + (Math.sign(deltaDeg) * step);
    }

    /**
         * AI의 결과에 따라 가속 및 물리 기본 이동을 처리합니다.
         * @param {number} [delta] 델타타임 (밀리초 등)
         * @param {object} [aiContext=null] 환경 데이터
         */
    fixedUpdate(delta, aiContext = null) {
        if (!this.active) return;

        this.runAIFixed(delta, aiContext);
        this.recoverAxisResistance(delta);

        this.speed.x += this.acc.x * this.accSpeed * delta;
        this.speed.y += this.acc.y * this.accSpeed * delta;

        this.position.x += this.speed.x * this.axisResistanceX * this.moveSpeed * delta;
        this.position.y += this.speed.y * this.axisResistanceY * this.moveSpeed * delta;

        this.updateAngularMotion(delta);
        this.#updateHeadingRotation(delta);
    }

    /**
         * 디스플레이 시스템의 WebGL 레이어를 통해 스프라이트를 렌더링합니다.
         * @param {{layer?: string, fill?: string, alpha?: number, sizeScale?: number, offsetX?: number, offsetY?: number}} [overrideOptions={}] - 임시 렌더 오버라이드 값입니다.
         */
    draw(overrideOptions = EMPTY_DRAW_OPTIONS) {
        if (!this.active) return;
        this.#syncRotationCache();

        const sizeScale = Number.isFinite(overrideOptions.sizeScale) ? overrideOptions.sizeScale : 1;
        const offsetX = Number.isFinite(overrideOptions.offsetX) ? overrideOptions.offsetX : 0;
        const offsetY = Number.isFinite(overrideOptions.offsetY) ? overrideOptions.offsetY : 0;
        const mergeOffsetX = (Number.isFinite(this.mergePullOffset?.x) ? this.mergePullOffset.x : 0)
            + (Number.isFinite(this.mergeSettleOffset?.x) ? this.mergeSettleOffset.x : 0);
        const mergeOffsetY = (Number.isFinite(this.mergePullOffset?.y) ? this.mergePullOffset.y : 0)
            + (Number.isFinite(this.mergeSettleOffset?.y) ? this.mergeSettleOffset.y : 0);
        const baseH = this.getRenderHeightPx() * sizeScale;
        const h = baseH * this.heightScale;
        const w = baseH * this.aspectRatio;
        const options = this.#renderOptions;
        options.x = this.renderPosition.x + offsetX + mergeOffsetX;
        options.y = (this.renderPosition.y - getObjectOffsetY()) + offsetY + mergeOffsetY;
        options.w = w;
        options.h = h;
        options.fill = overrideOptions.fill ?? this.fill;
        options.alpha = overrideOptions.alpha ?? this.alpha;
        renderGL(overrideOptions.layer || 'object', options);
        const debugOptions = this.#collisionDebugOptions;
        debugOptions.enemyType = this.type ?? this.shapeType;
        debugOptions.width = w;
        debugOptions.height = h;
        debugOptions.rotationRadians = (Number.isFinite(options.rotation) ? options.rotation : 0) * DEGREES_TO_RADIANS;
        debugOptions.renderX = options.x;
        debugOptions.renderY = options.y;
        drawEnemyCollisionDebugCircles(debugOptions);
    }
}
